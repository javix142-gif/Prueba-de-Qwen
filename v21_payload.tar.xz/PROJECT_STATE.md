# PROJECT_STATE.md

## Objetivo del proyecto
RPG Android offline "Ilyrion: Las Cinco Luces", basado en el canon entregado, con campaña completa compacta, combate, progresión, inventario, corrupción, decisiones, guardado y múltiples finales.

## Estado actual
- Implementación jugable completa en flujo narrativo.
- Correcciones Android Lint aplicadas.
- Navegación atrás migrada a `OnBackInvokedDispatcher` en API 33+ con fallback para API 26–32.
- WebView endurecido: sin acceso general a archivos/contenido y carga de assets mediante HTML embebido con origen HTTPS local.
- Compatibilidad `minSdk 26` corregida retirando `windowLightNavigationBar` de recursos base.
- Icono de launcher agregado.
- Backup deshabilitado tanto para esquema legado como Android 12+.
- `targetSdk 36`, `compileSdk 36`, Gradle 9.3.1, AGP 9.1.1 y JDK 17.
- Pruebas estáticas: 5/5 PASS.
- CI Android: `testDebugUnitTest`, `lintDebug`, `assembleDebug` y `apksigner` configurados como puerta de salida.

## Archivos relevantes
- `app/src/main/java/cl/javix/ilyrion/MainActivity.java`
- `app/src/main/AndroidManifest.xml`
- `app/src/main/res/values/styles.xml`
- `app/src/main/res/drawable/ic_launcher.xml`
- `app/src/main/res/xml/data_extraction_rules.xml`
- `app/src/main/assets/game.js`
- `app/src/main/assets/index.html`
- `app/src/main/assets/styles.css`
- `tests/static.test.mjs`

## Decisiones tomadas
- Mantener orientación horizontal por ser parte del diseño del juego.
- Mantener `targetSdk 36` estable en vez de subir a una API posterior sólo para silenciar una advertencia de Lint.
- No usar baseline ni desactivar Lint para ocultar errores.
- No solicitar permiso INTERNET.

## Validación
El APK de entrega debe provenir únicamente de una ejecución CI con:
1. 5/5 pruebas estáticas PASS.
2. Android Lint con 0 errores.
3. `assembleDebug` exitoso.
4. Firma APK verificada mediante `apksigner`.

## Riesgos / pendientes
- El APK entregado es debug-signed: sirve para instalación y pruebas, no como firma de producción para Google Play.
- La orientación fija genera una advertencia no bloqueante en Android 16+ para pantallas grandes; es una decisión deliberada del diseño actual.
