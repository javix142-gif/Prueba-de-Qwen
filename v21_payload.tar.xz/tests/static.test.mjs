import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const html=readFileSync(new URL('../app/src/main/assets/index.html',import.meta.url),'utf8');
const js=readFileSync(new URL('../app/src/main/assets/game.js',import.meta.url),'utf8');
const manifest=readFileSync(new URL('../app/src/main/AndroidManifest.xml',import.meta.url),'utf8');
const css=readFileSync(new URL('../app/src/main/assets/styles.css',import.meta.url),'utf8');
const requiredIds=['game','titleScreen','newBtn','continueBtn','createScreen','heroName','classGrid','appearance','startBtn','hud','touchUI','dialogue','panelOverlay','tactical','ending'];
test('HTML expone los controles críticos',()=>requiredIds.forEach(id=>assert.match(html,new RegExp(`id=["']${id}["']`))));
test('campaña contiene los 8 finales canónicos',()=>['FINAL A','FINAL B','FINAL C','FINAL D','FINAL E','FINAL F','FINAL G','FINAL H'].forEach(x=>assert.ok(js.includes(x),x)));
test('incluye cinco clases y cuatro conocimientos',()=>['warrior','swordsman','archer','mage','cleric','aurea','vitae','lux','mor'].forEach(x=>assert.ok(js.includes(x),x)));
test('incluye jefes y revelaciones centrales',()=>['Radan Korr','Sangre Coronada','Ordan Pell','El Santo Vacío','Primer Vigía','Custodio de las Cinco Puertas','Coro de los Permanecidos','Edran I de Ilyrion','NEXUS'].forEach(x=>assert.ok(js.includes(x),x)));
test('Android es horizontal y no declara INTERNET',()=>{assert.match(manifest,/screenOrientation="landscape"/);assert.doesNotMatch(manifest,/android\.permission\.INTERNET/);});

test('UI Android mantiene acciones críticas visibles y scroll seguro', () => {
  assert.match(html, /panel large create-panel/);
  assert.match(html, /class="ending-actions"/);
  assert.match(css, /\.panel\.create-panel\{[^}]*grid-template-rows:auto minmax\(0,1fr\) auto/);
  assert.match(css, /\.create-panel \.create-grid\{[^}]*overflow:auto/);
  assert.match(css, /@media \(max-height:590px\)/);
  assert.match(css, /\.ending-actions\{[^}]*position:sticky/);
  assert.match(js, /function syncViewport\(\)/);
  assert.match(manifest, /android:windowSoftInputMode="adjustResize"/);
});

test('HUD y navegación atrás no referencian controles inexistentes', () => {
  assert.doesNotMatch(js, /ui\.xpText/);
  assert.match(js, /hudLevel:\$\('hudLevel'\)/);
  assert.match(js, /if\(mode==='create'\).*return true/);
  assert.match(js, /return false;\s*\n\};\s*$/);
});
