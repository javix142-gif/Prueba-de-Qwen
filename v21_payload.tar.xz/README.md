# Ilyrion: Las Cinco Luces

RPG de fantasía oscura para Android, completamente offline, basado en el canon adjunto del proyecto.

## Versión 1.0.0

- `applicationId`: `cl.javix.ilyrion`
- Android mínimo: API 26 (Android 8.0)
- `compileSdk` / `targetSdk`: 36
- orientación: horizontal
- sin cuenta, backend, publicidad ni permiso de Internet

## Contenido implementado

- Campaña completa en estructura narrativa: Prólogo + capítulos 1–13 + epílogo variable.
- Liria, Ceniza/Cyrion, Aureval, Vesperia, Serath, Keldran, Cyrion Interior, Concordia Técnica y NEXUS.
- Cinco clases: Guerrero, Espadachín, Arquero, Hechicero y Clérigo.
- Exploración top-down con joystick táctil y teclado para pruebas.
- Combate ARPG con ataque, habilidad, esquiva, enemigos y proyectiles.
- Combates tácticos para Radan Korr, Sangre Coronada, Ordan Pell, Santo Vacío, Primer Vigía, Pentarca, Coro y Edran.
- EXP/niveles, cuatro atributos, talentos, inventario, equipo, rarezas y forja +1 a +10.
- Oro, pociones, Vitae, saturación y corrupción.
- Decisiones persistentes sin barra Bien/Mal: reputación, cooperación, influencia, conocimiento, estados regionales, vidas salvadas y corrupción.
- Cuatro Llaves + Collar, AUREA/Vitae/LUX/MOR, Quinta Concordia, Edran y NEXUS.
- Finales A–H, con rutas condicionadas para Nueva Concordia, Imperio, Ascensión y Éxodo.
- Guardado automático local y Nueva Partida+.

## Compilación

Requiere JDK 17, Android SDK 36 y un Gradle compatible con AGP 9.1.1. La CI descarga Gradle 9.3.1 desde la distribución oficial y ejecuta tests, lint y `assembleDebug`.

## Validación

```bash
node --check app/src/main/assets/game.js
node --test tests/static.test.mjs
```

La compilación Android se realiza en GitHub Actions. El APK de depuración es para sideload/prueba personal y no usa una firma release permanente.

## Alcance

Esta entrega implementa toda la línea argumental y los sistemas nucleares en formato indie compacto y data-driven. No pretende equivaler en volumen de arte, diálogos, mapas y horas a una producción comercial de 8–15 horas con assets hechos por un equipo; los documentos canónicos quedan incluidos para continuar ampliando contenido sin alterar la historia.
